Openni2_Opencv_wrapper
======================

A simple wrapper for Openni2 in Opencv
