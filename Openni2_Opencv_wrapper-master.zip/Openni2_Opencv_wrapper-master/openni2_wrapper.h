#include "OpenNI.h"
#include "opencv2/core/core.hpp"
#include "opencv/cv.h"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/highgui/highgui_c.h"
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/calib3d.hpp"
#include <string>
#include <iostream>

enum CameraMode {NI_SENSOR_DEPTH, NI_SENSOR_COLOR, CV_CAMERA};
/*enum Parameters {CV_CAP_PROP_POS_MSEC, CV_CAP_PROP_POS_FRAMES, CV_CAP_PROP_POS_AVI_RATIO, CV_CAP_PROP_FRAME_WIDTH, CV_CAP_PROP_FRAME_HEIGHT,
                 CV_CAP_PROP_FPS, CV_CAP_PROP_FOURCC, CV_CAP_PROP_FRAME_COUNT, CV_CAP_PROP_FORMAT, CV_CAP_PROP_MODE, CV_CAP_PROP_BRIGHTNESS, 
                 CV_CAP_PROP_CONTRAST, CV_CAP_PROP_SATURATION, CV_CAP_PROP_HUE, CV_CAP_PROP_GAIN, CV_CAP_PROP_EXPOSURE, CV_CAP_PROP_CONVERT_RGB,
                 CV_CAP_PROP_WHITE_BALANCE, CV_CAP_PROP_RECTIFICATION};
*/

/* VideoWrapper allows to translate an OpenNI VideoStream into an OpenCV stream.
 * Use open() to create either a openni::VideoStream or a cv::VideoCapture.
 * Call readFrame() to obtain the next frame in the stream.
 * In case of openni::VideoStream the frame is converted into a cv::Mat frame.
 */
class VideoWrapper {
public:
			
	bool open(openni::Device &device, CameraMode cm);
	bool open(std::string input_video);
	bool open(int val);
	double get(int id);
	bool set(int id, double value);
	bool setUndistortParameters(std::string path);
	
	bool isOpened() { return is_opened_; }
	bool readFrame(cv::Mat &frame);
	bool readFrameUndistorted(cv::Mat &frame);
	void operator>>(cv::Mat &frame) { readFrame(frame); }
	void close();

private:
	cv::Mat camera_matrix_, dist_coeffs_;
	cv::Mat map1_, map2_;
	bool distortion_parameters_set_ = false;
	bool is_opened_ = false;

	CameraMode cm_;
	cv::VideoCapture video_capture_;
	openni::VideoStream video_stream_;	
};